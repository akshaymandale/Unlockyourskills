// SCORM API Implementation
let scormAPI = null;
let isInitialized = false;
let currentData = {
    location: '',
    score: 0,
    status: 'not attempted',
    suspendData: '{}',
    sessionTime: '0000:00:00',
    totalTime: '0000:00:00',
    progress: 0
};

// Debug logging
function log(message) {
    const console = document.getElementById('debugConsole');
    const timestamp = new Date().toLocaleTimeString();
    console.innerHTML += `[${timestamp}] ${message}\n`;
    console.scrollTop = console.scrollHeight;
}

// Initialize SCORM API
function initializeAPI() {
    try {
        // Try to find SCORM API
        if (window.API) {
            scormAPI = window.API;
            log('Found window.API');
        } else if (window.Debug_api) {
            scormAPI = window.Debug_api;
            log('Found window.Debug_api');
        } else {
            // Create mock API if none exists
            scormAPI = createMockAPI();
            log('Created mock SCORM API');
        }

        // Initialize
        const result = scormAPI.LMSInitialize('');
        if (result === 'true') {
            isInitialized = true;
            document.getElementById('apiStatus').innerHTML = '✅ SCORM API Initialized Successfully';
            document.getElementById('apiStatus').className = 'status success';
            log('SCORM API initialized successfully');
        } else {
            throw new Error('Failed to initialize SCORM API');
        }
    } catch (error) {
        document.getElementById('apiStatus').innerHTML = '❌ Error: ' + error.message;
        document.getElementById('apiStatus').className = 'status error';
        log('Error initializing SCORM API: ' + error.message);
    }
}

// Create mock SCORM API if none exists
function createMockAPI() {
    return {
        LMSInitialize: function(param) {
            log('Mock API: LMSInitialize called with: ' + param);
            return 'true';
        },
        
        LMSFinish: function(param) {
            log('Mock API: LMSFinish called with: ' + param);
            return 'true';
        },
        
        LMSGetValue: function(element) {
            log('Mock API: LMSGetValue called for: ' + element);
            switch(element) {
                case 'cmi.location': return currentData.location;
                case 'cmi.score.raw': return currentData.score;
                case 'cmi.lesson_status': return currentData.status;
                case 'cmi.suspend_data': return currentData.suspendData;
                case 'cmi.session_time': return currentData.sessionTime;
                case 'cmi.total_time': return currentData.totalTime;
                default: return '';
            }
        },
        
        LMSSetValue: function(element, value) {
            log('Mock API: LMSSetValue called for: ' + element + ' with value: ' + value);
            switch(element) {
                case 'cmi.location': currentData.location = value; break;
                case 'cmi.score.raw': currentData.score = value; break;
                case 'cmi.lesson_status': currentData.status = value; break;
                case 'cmi.suspend_data': currentData.suspendData = value; break;
                case 'cmi.session_time': currentData.sessionTime = value; break;
                case 'cmi.total_time': currentData.totalTime = value; break;
            }
            return 'true';
        },
        
        LMSCommit: function(param) {
            log('Mock API: LMSCommit called with: ' + param);
            return 'true';
        },
        
        LMSGetLastError: function() {
            return '0';
        },
        
        LMSGetErrorString: function(errorCode) {
            return 'No error';
        },
        
        LMSGetDiagnostic: function(errorCode) {
            return 'No diagnostic information';
        }
    };
}

// Check API availability
function checkAPI() {
    if (window.API) {
        document.getElementById('apiStatus').innerHTML = '✅ window.API found';
        document.getElementById('apiStatus').className = 'status success';
        log('window.API found');
    } else if (window.Debug_api) {
        document.getElementById('apiStatus').innerHTML = '✅ window.Debug_api found';
        document.getElementById('apiStatus').className = 'status success';
        log('window.Debug_api found');
    } else {
        document.getElementById('apiStatus').innerHTML = '❌ No SCORM API found';
        document.getElementById('apiStatus').className = 'status error';
        log('No SCORM API found');
    }
}

// Terminate API
function terminateAPI() {
    if (scormAPI && isInitialized) {
        try {
            const result = scormAPI.LMSFinish('');
            if (result === 'true') {
                isInitialized = false;
                document.getElementById('apiStatus').innerHTML = '✅ SCORM API Terminated Successfully';
                document.getElementById('apiStatus').className = 'status success';
                log('SCORM API terminated successfully');
            }
        } catch (error) {
            log('Error terminating SCORM API: ' + error.message);
        }
    }
}

// Progress functions
function updateProgress(percent) {
    currentData.progress = percent;
    document.getElementById('progressFill').style.width = percent + '%';
    document.getElementById('progressText').textContent = percent + '%';
    
    if (scormAPI && isInitialized) {
        try {
            scormAPI.LMSSetValue('cmi.progress_measure', percent / 100);
            log('Progress set to: ' + percent + '%');
        } catch (error) {
            log('Error setting progress: ' + error.message);
        }
    }
}

// Location functions
function setLocation() {
    const location = document.getElementById('locationInput').value;
    if (location) {
        currentData.location = location;
        
        if (scormAPI && isInitialized) {
            try {
                scormAPI.LMSSetValue('cmi.location', location);
                showStatus('locationStatus', 'Location set successfully: ' + location, 'success');
                log('Location set to: ' + location);
            } catch (error) {
                showStatus('locationStatus', 'Error setting location: ' + error.message, 'error');
                log('Error setting location: ' + error.message);
            }
        } else {
            showStatus('locationStatus', 'SCORM API not initialized', 'error');
        }
    }
}

function getLocation() {
    if (scormAPI && isInitialized) {
        try {
            const location = scormAPI.LMSGetValue('cmi.location');
            document.getElementById('locationInput').value = location;
            showStatus('locationStatus', 'Location retrieved: ' + location, 'success');
            log('Location retrieved: ' + location);
        } catch (error) {
            showStatus('locationStatus', 'Error getting location: ' + error.message, 'error');
            log('Error getting location: ' + error.message);
        }
    } else {
        showStatus('locationStatus', 'SCORM API not initialized', 'error');
    }
}

// Score functions
function setScore() {
    const score = document.getElementById('scoreInput').value;
    if (score >= 0 && score <= 100) {
        currentData.score = score;
        document.getElementById('scoreDisplay').textContent = 'Score: ' + score;
        
        if (scormAPI && isInitialized) {
            try {
                scormAPI.LMSSetValue('cmi.score.raw', score);
                log('Score set to: ' + score);
            } catch (error) {
                log('Error setting score: ' + error.message);
            }
        }
    }
}

function getScore() {
    if (scormAPI && isInitialized) {
        try {
            const score = scormAPI.LMSGetValue('cmi.score.raw');
            document.getElementById('scoreInput').value = score;
            document.getElementById('scoreDisplay').textContent = 'Score: ' + score;
            log('Score retrieved: ' + score);
        } catch (error) {
            log('Error getting score: ' + error.message);
        }
    }
}

// Status functions
function setStatus() {
    const status = document.getElementById('statusSelect').value;
    currentData.status = status;
    
    if (scormAPI && isInitialized) {
        try {
            scormAPI.LMSSetValue('cmi.lesson_status', status);
            showStatus('statusStatus', 'Status set successfully: ' + status, 'success');
            log('Status set to: ' + status);
        } catch (error) {
            showStatus('statusStatus', 'Error setting status: ' + error.message, 'error');
            log('Error setting status: ' + error.message);
        }
    } else {
        showStatus('statusStatus', 'SCORM API not initialized', 'error');
    }
}

function getStatus() {
    if (scormAPI && isInitialized) {
        try {
            const status = scormAPI.LMSGetValue('cmi.lesson_status');
            document.getElementById('statusSelect').value = status;
            showStatus('statusStatus', 'Status retrieved: ' + status, 'success');
            log('Status retrieved: ' + status);
        } catch (error) {
            showStatus('statusStatus', 'Error getting status: ' + error.message, 'error');
            log('Error getting status: ' + error.message);
        }
    } else {
        showStatus('statusStatus', 'SCORM API not initialized', 'error');
    }
}

// Suspend data functions
function setSuspendData() {
    const suspendData = document.getElementById('suspendInput').value;
    if (suspendData) {
        currentData.suspendData = suspendData;
        
        if (scormAPI && isInitialized) {
            try {
                scormAPI.LMSSetValue('cmi.suspend_data', suspendData);
                showStatus('suspendStatus', 'Suspend data set successfully', 'success');
                log('Suspend data set: ' + suspendData);
            } catch (error) {
                showStatus('suspendStatus', 'Error setting suspend data: ' + error.message, 'error');
                log('Error setting suspend data: ' + error.message);
            }
        } else {
            showStatus('suspendStatus', 'SCORM API not initialized', 'error');
        }
    }
}

function getSuspendData() {
    if (scormAPI && isInitialized) {
        try {
            const suspendData = scormAPI.LMSGetValue('cmi.suspend_data');
            document.getElementById('suspendInput').value = suspendData;
            showStatus('suspendStatus', 'Suspend data retrieved', 'success');
            log('Suspend data retrieved: ' + suspendData);
        } catch (error) {
            showStatus('suspendStatus', 'Error getting suspend data: ' + error.message, 'error');
            log('Error getting suspend data: ' + error.message);
        }
    } else {
        showStatus('suspendStatus', 'SCORM API not initialized', 'error');
    }
}

// Time functions
function setSessionTime() {
    const time = document.getElementById('sessionTimeInput').value;
    if (time) {
        currentData.sessionTime = time;
        
        if (scormAPI && isInitialized) {
            try {
                scormAPI.LMSSetValue('cmi.session_time', time);
                showStatus('timeStatus', 'Session time set successfully: ' + time, 'success');
                log('Session time set to: ' + time);
            } catch (error) {
                showStatus('timeStatus', 'Error setting session time: ' + error.message, 'error');
                log('Error setting session time: ' + error.message);
            }
        } else {
            showStatus('timeStatus', 'SCORM API not initialized', 'error');
        }
    }
}

function getSessionTime() {
    if (scormAPI && isInitialized) {
        try {
            const time = scormAPI.LMSGetValue('cmi.session_time');
            document.getElementById('sessionTimeInput').value = time;
            showStatus('timeStatus', 'Session time retrieved: ' + time, 'success');
            log('Session time retrieved: ' + time);
        } catch (error) {
            showStatus('timeStatus', 'Error getting session time: ' + error.message, 'error');
            log('Error getting session time: ' + error.message);
        }
    } else {
        showStatus('timeStatus', 'SCORM API not initialized', 'error');
    }
}

// Export functions
function exportAllData() {
    const data = {
        timestamp: new Date().toISOString(),
        scormData: currentData,
        apiStatus: {
            isInitialized: isInitialized,
            hasAPI: !!scormAPI
        }
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'scorm_test_data.json';
    link.click();
    
    URL.revokeObjectURL(url);
    showStatus('exportStatus', 'Data exported successfully', 'success');
    log('Data exported: ' + dataStr);
}

function clearAllData() {
    currentData = {
        location: '',
        score: 0,
        status: 'not attempted',
        suspendData: '{}',
        sessionTime: '0000:00:00',
        totalTime: '0000:00:00',
        progress: 0
    };
    
    document.getElementById('progressFill').style.width = '0%';
    document.getElementById('progressText').textContent = '0%';
    document.getElementById('locationInput').value = '';
    document.getElementById('scoreInput').value = '0';
    document.getElementById('statusSelect').value = 'not attempted';
    document.getElementById('suspendInput').value = '';
    document.getElementById('sessionTimeInput').value = '';
    document.getElementById('scoreDisplay').textContent = 'Score: 0';
    
    showStatus('exportStatus', 'All data cleared', 'success');
    log('All data cleared');
}

// Utility functions
function showStatus(elementId, message, type) {
    const element = document.getElementById(elementId);
    element.innerHTML = message;
    element.className = 'status ' + type;
    element.style.display = 'block';
    
    setTimeout(() => {
        element.style.display = 'none';
    }, 3000);
}

function clearConsole() {
    document.getElementById('debugConsole').innerHTML = '';
}

// Auto-save functionality
function autoSave() {
    if (scormAPI && isInitialized) {
        try {
            scormAPI.LMSCommit('');
            log('Auto-save completed');
        } catch (error) {
            log('Auto-save failed: ' + error.message);
        }
    }
}

// Initialize on page load
window.addEventListener('load', function() {
    log('Test SCORM package loaded');
    checkAPI();
    
    // Auto-save every 30 seconds
    setInterval(autoSave, 30000);
});

// Save data before page unload
window.addEventListener('beforeunload', function() {
    if (scormAPI && isInitialized) {
        try {
            scormAPI.LMSCommit('');
            scormAPI.LMSFinish('');
            log('Data saved before page unload');
        } catch (error) {
            log('Error saving data before unload: ' + error.message);
        }
    }
});
