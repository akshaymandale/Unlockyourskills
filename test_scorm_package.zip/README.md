# 🧪 Test SCORM Package

This is a comprehensive test SCORM package that demonstrates all basic SCORM functionality for testing and development purposes.

## 📁 Package Structure

```
test_scorm_package/
├── imsmanifest.xml      # SCORM manifest file (defines package structure)
├── index.html           # Main launch file (entry point)
├── styles.css           # CSS styling
├── script.js            # JavaScript functionality
└── README.md            # This file
```

## 🚀 Launch Path

- **Launch File**: `index.html`
- **SCORM Version**: 1.2
- **Package Type**: SCO (Sharable Content Object)

## ✨ Features

### 📊 Progress Tracking
- Visual progress bar (0%, 25%, 50%, 75%, 100%)
- Progress measurement via SCORM API

### 📍 Location Tracking
- Set/get current location (e.g., "slide1", "page2")
- Tests `cmi.location` SCORM data element

### 🎯 Score Management
- Set/get score (0-100)
- Tests `cmi.score.raw` SCORM data element

### 📋 Lesson Status
- Set/get lesson status (not attempted, incomplete, completed, failed, passed)
- Tests `cmi.lesson_status` SCORM data element

### 💾 Suspend Data
- Set/get suspend data (JSON format)
- Tests `cmi.suspend_data` SCORM data element

### ⏱️ Time Tracking
- Set/get session time (HH:MM:SS format)
- Tests `cmi.session_time` SCORM data element

### 🔌 SCORM API Status
- Check for available SCORM API
- Initialize/terminate SCORM connection
- Tests all basic SCORM API functions

### 📤 Data Export
- Export all SCORM data as JSON
- Clear all data
- Auto-save every 30 seconds

### 🐛 Debug Console
- Real-time logging of all SCORM operations
- Timestamps for debugging

## 🔧 Installation

1. **Upload to SCORM System**:
   - Go to your VLR → SCORM tab
   - Click "Add New SCORM Package"
   - Upload the ZIP file
   - Set title, version, and category
   - Save

2. **Test Through Content Viewer**:
   - Go to My Courses
   - Find the test SCORM package
   - Click to open
   - Should open in content viewer with SCORM API wrapper

## 🧪 Testing

### Expected Results When Working:
- ✅ **API Status**: "window.API found"
- ✅ **Initialize**: "SCORM API Initialized Successfully"
- ✅ **All Functions**: Set Location, Set Score, Set Status, etc. should work
- ✅ **Debug Console**: Should show SCORM API calls being made

### If Not Working:
- ❌ **API Status**: "No SCORM API found"
- ❌ **Initialize**: Button won't work
- ❌ **Functions**: All SCORM functions will fail

## 📋 Test Checklist

- [ ] Upload ZIP to VLR → SCORM
- [ ] Open through My Courses → Content Viewer
- [ ] Check if "Check API" shows "window.API found"
- [ ] Try "Initialize" button
- [ ] Test setting location, score, status
- [ ] Check debug console for SCORM API calls
- [ ] Test progress tracking
- [ ] Test data export

## 🚨 Troubleshooting

### Common Issues:

1. **"No SCORM API found"**:
   - API wrapper not injecting properly
   - Cross-origin issues
   - Timing issues

2. **Functions not working**:
   - SCORM API not initialized
   - Missing API wrapper
   - Browser security blocking

3. **Data not saving**:
   - Progress tracker not ready
   - Database connection issues
   - Missing course context

## 🔍 Debug Information

The package includes comprehensive debugging:
- Real-time console logging
- API status monitoring
- Error handling and display
- Data export functionality

## 📊 SCORM Compliance

This package is designed to work with:
- **SCORM 1.2** ✅
- **SCORM 2004** ✅
- **Any SCORM-compliant LMS** ✅
- **Custom SCORM API wrappers** ✅

## 🎯 Use Cases

- **Development Testing**: Test SCORM API wrapper functionality
- **LMS Validation**: Verify SCORM compliance
- **Training**: Demonstrate SCORM concepts
- **Debugging**: Troubleshoot SCORM issues
- **Quality Assurance**: Validate SCORM implementations

## 📞 Support

If you encounter issues:
1. Check the debug console for error messages
2. Verify SCORM API wrapper is working
3. Check browser console for additional errors
4. Ensure proper course context is set

---

**Note**: This package is designed for testing purposes and includes mock SCORM API functionality when no external API is available.
